<?php
$domain=Request::root();
?>
<a href="{{$domain}}/reset-password/{{$token}}">Password Reset</a>