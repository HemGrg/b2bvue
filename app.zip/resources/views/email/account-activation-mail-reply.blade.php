<!DOCTYPE html>
<html>

<head>
    <title>Account Verified Mail</title>
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap"
        rel="stylesheet">
</head>
<style>
</style>

<body>
    
    <div style="font-color:#000000 ; padding: 15px; max-width: 500px; background-color: #ffff;font-family: 'Open Sans', sans-serif;
   margin: 0 0;">
        
        <div>
           

               
                <div> Dear {{$name}}, </div>
                
                
                <div> Your account has been activated!! Thank you!! </div>

               
                
                
               

            <div>

                
            </div>
        </div>

    </div>

</body>

</html>