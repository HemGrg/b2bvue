@php
$user = Auth::user();
 $roles = [];
foreach($user->roles as $role){
    $slug = $role->slug;
    array_push($roles,$slug);
}
$user_access = explode(',', $user->access_level);
@endphp


<nav class="page-sidebar" id="sidebar">
    <div id="sidebar-collapse">
        <div class="admin-block d-flex">
            <div>
                <img src="{{asset('/assets/admin/images/admin-avatar.png')}}" width="45px" />
            </div>
            <div class="admin-info">
                <div class="font-strong">{{ @Auth::user()->name }}</div>
            </div>
        </div>
        <ul class="side-menu metismenu">
            <li>
                <a class="active" href="{{route('dashboard')}}"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Dashboard</span>
                </a>
            </li>
            <li class="heading">Menu</li>
            @if(in_array('super_admin' ,$roles) || (in_array('admin' ,$roles) || in_array('web-setting', $user_access)))
            <li>
                <a href="#">
                    <i class="sidebar-item-icon fa fa-internet-explorer"></i>
                    <span class="nav-label">Site Setting</span>
                    <i class="fa fa-cogs arrow"></i>
                </a>
            </li>
            @endif

            @if(in_array('super_admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-user-circle"></i>
                    <span class="nav-label">Vendor Management</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('vendor.getApprovedVendors')}}">
                            <span class="fa fa-eye"></span>
                            Approved Vendors
                        </a>
                    </li>

                    <li>
                        <a href="{{route('vendor.getNewVendors')}}">
                            <span class="fa fa-eye"></span>
                            New Vendors
                        </a>
                    </li>

                    <li>
                        <a href="{{route('vendor.getSuspendedVendors')}}">
                            <span class="fa fa-eye"></span>
                            Suspended Vendors
                        </a>
                    </li>
                </ul>
            </li>
             @endif
             @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-first-order"></i>
                    <span class="nav-label">Order Management</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="{{route('order.index')}}">
                            <span class="fa fa-eye"></span>
                            All Orders
                        </a>
                    </li>
                </ul>
            </li>
             @endif
            @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles)){
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-tasks"></i>
                    <span class="nav-label">Roles</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('role.create')}}">
                            <span class="fa fa-plus"></span>
                            Add Role
                        </a>
                    </li>

                    <li>
                        <a href="{{route('role.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Roles
                        </a>
                    </li>
                </ul>
            </li>
             @endif 

            {{-- @if($role == 'admin' || ($role == 'staff' && in_array('order-list', $user_access)) ) --}}
            {{-- <li>
                <a href="{{route('order-list')}}">
                    <i class="sidebar-item-icon fa fa-shopping-cart"></i>
                    <span class="nav-label">Order list</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li> --}}
            {{-- @endif --}}
            
            {{-- <li>
                <a href="{{route('review.index')}}"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Reviews</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li> --}}


            {{-- <li>
                <a href="{{route('weekly_report')}}"><i class="sidebar-item-icon fa fa-th-large"></i>
                    <span class="nav-label">Sales Report</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li> --}}

            {{-- <li>
                <a href="{{route('user-list')}}">
                    <i class="sidebar-item-icon fa fa-users"></i>
                    <span class="nav-label">Customers</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li> --}}

            <!-- @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-file"></i>
                    <span class="nav-label">Sliders</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="#">
                            <span class="fa fa-plus"></span>
                            Add Slider
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="fa fa-circle-o"></span>
                            All Slider
                        </a>
                    </li>
                </ul>
            </li>
            @endif  -->

            @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-list-alt"></i>
                    <span class="nav-label">Categories</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    
                    <li>
                        <a href="{{route('category.create')}}">
                            <span class="fa fa-plus"></span>
                            Add Category
                        </a>
                    </li>
                    
                    <li>
                        <a href="{{route('category.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Category
                        </a>
                    </li>
                </ul>
            </li>
             @endif 

             @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-shopping-cart"></i>
                    <span class="nav-label">Sub Categories</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('subcategory.create')}}">
                            <span class="fa fa-plus"></span>
                            Add Subcategory
                        </a>
                    </li>

                    <li>
                        <a href="{{route('subcategory.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All  SubCategories
                        </a>
                    </li>
                </ul>
            </li>
             @endif 

             @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-product-hunt"></i>
                    <span class="nav-label">Product Attributes</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('productattribute.create')}}">
                            <span class="fa fa-plus"></span>
                            Add Product Attribute
                        </a>
                    </li>

                    <li>
                        <a href="{{route('productattribute.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Product Attributes
                        </a>
                    </li>
                </ul>
            </li>
             @endif 

             @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-product-hunt"></i>
                    <span class="nav-label">Product</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('product.create')}}">
                            <span class="fa fa-plus"></span>
                            Add Product
                        </a>
                    </li>

                    <li>
                        <a href="{{route('product.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Products
                        </a>
                    </li>
                </ul>
            </li>
             @endif 

            {{-- @if($role == 'admin' || ($role == 'staff' && in_array('advertise', $user_access)) ) --}}
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-adn"></i>
                    <span class="nav-label">Advertise</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('advertisement.create')}}">
                            <span class="fa fa-plus"></span>
                            Add New
                        </a>
                    </li>

                    <li>
                        <a href="{{route('advertisement.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Lists
                        </a>
                    </li>
                </ul>
            </li>
            {{-- @endif --}}

            <!-- {{-- @if($role == 'admin' || ($role == 'staff' && in_array('post', $user_access)) ) --}}
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-calendar"></i>
                    <span class="nav-label">Blogs</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">
                    <li>
                        <a href="#">
                            <span class="fa fa-plus"></span>
                            Add Blog
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="fa fa-circle-o"></span>
                            All Blog
                        </a>
                    </li>
                </ul>
            </li>
            {{-- @endif --}} -->

            <!-- {{-- @if($role == 'admin' || ($role == 'staff' && in_array('advertslider', $user_access)) ) --}}
            {{-- <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-sitemap"></i>
                    <span class="nav-label">Advertise Slider</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('advertslider.create')}}">
                            <span class="fa fa-plus"></span>
                            Add New
                        </a>
                    </li>

                    <li>
                        <a href="{{route('advertslider.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Lists
                        </a>
                    </li>
                </ul>
            </li> --}}
            {{-- @endif --}} -->

            @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-gift"></i>
                    <span class="nav-label">Offer</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('offer.create')}}">
                            <span class="fa fa-plus"></span>
                            Add New
                        </a>
                    </li>

                    <li>
                        <a href="{{route('offer.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Lists
                        </a>
                    </li>
                </ul>
            </li>
            @endif

            @if(in_array('super_admin' ,$roles) || in_array('admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-dollar"></i>
                    <span class="nav-label">Brand</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('brand.create')}}">
                            <span class="fa fa-plus"></span>
                            Add New
                        </a>
                    </li>

                    <li>
                        <a href="{{route('brand.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Lists
                        </a>
                    </li>
                </ul>
            </li>
             @endif 

             @if(in_array('super_admin' ,$roles))
            <li>
                <a href="javascript:;">
                    <i class="sidebar-item-icon fa fa-user"></i>
                    <span class="nav-label">Admin User</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
                <ul class="nav-2-level collapse">

                    <li>
                        <a href="{{route('user.create')}}">
                            <span class="fa fa-plus"></span>
                            Add New
                        </a>
                    </li>

                    <li>
                        <a href="{{route('user.index')}}">
                            <span class="fa fa-circle-o"></span>
                            All Lists
                        </a>
                    </li>
                </ul>
            </li>
             @endif

            {{-- <li>
                <a href="{{route('message-list')}}">
                    <i class="sidebar-item-icon fa fa-envelope"></i>
                    <span class="nav-label">Messages</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li> --}}

            <!-- {{-- @if($role == 'admin' || ($role == 'staff' && in_array('page', $user_access)) ) --}}
            <li>
                <a href="#">
                    <i class="sidebar-item-icon fa fa-file"></i>
                    <span class="nav-label">Pages</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li>
            {{-- @endif --}} -->

            <!-- <li>
                <a href="#">
                    <i class="sidebar-item-icon fa fa-thumbs-up"></i>
                    <span class="nav-label">Subscribers</span>
                    <i class="fa fa-angle-left arrow"></i>
                </a>
            </li> -->
            {{-- <li>
                <a href="{{route('wishlist.index')}}">
            <i class="sidebar-item-icon fa fa-thumbs-up"></i>
            <span class="nav-label">Wishlist</span>
            <i class="fa fa-angle-left arrow"></i>
            </a>
            </li> --}}
        </ul>
    </div>
</nav>